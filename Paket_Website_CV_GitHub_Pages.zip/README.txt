PAKET WEBSITE CV RHAMDANI SYAHID

Isi:
- index.html: halaman website CV
- assets/profile.jpg: foto profil
- CV_Rhamdani_Syahid.pdf: CV PDF publik (alamat rumah lengkap tidak dicantumkan)

Cara publikasi:
1. Buat repository public bernama syahiddhani3.github.io di GitHub.
2. Unggah seluruh isi folder ini (index.html, folder assets, PDF, README.txt) ke root repository.
3. Buka Settings > Pages.
4. Pada Build and deployment, pilih Deploy from a branch.
5. Pilih branch main dan folder /(root), lalu Save.
6. Tunggu proses publikasi; buka https://syahiddhani3.github.io/

Catatan privasi: website dan file yang dipublikasikan bisa dilihat siapa saja. Periksa kembali informasi kontak sebelum menerbitkan.
